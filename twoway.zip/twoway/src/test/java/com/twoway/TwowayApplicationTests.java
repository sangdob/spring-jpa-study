package com.twoway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwowayApplicationTests {

	@Test
	void contextLoads() {
	}

}
