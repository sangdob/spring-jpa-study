package com.twoway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwowayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwowayApplication.class, args);
	}

}
